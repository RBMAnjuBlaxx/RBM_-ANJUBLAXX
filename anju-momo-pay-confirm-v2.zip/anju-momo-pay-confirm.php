<?php
/**
 * Plugin Name: Anju MoMo Pay & Confirm
 * Description: Adds MoMo instructions, Twi support, QR code, customer confirmation form, admin dashboard & email alert to WooCommerce.
 * Version: 2.0
 * Author: Anju Data Hub
 */

defined( 'ABSPATH' ) || exit;

// Payment box (reused)
function anju_render_momo_payment_box() {
    echo '<div style="background:#f0f8ff; border:1px solid #ccc; padding:12px; margin-top:15px; font-size:14px;">';
    echo '<strong>Mobile Money Payment Details</strong><br>';
    echo '📱 <strong>0201258303</strong><br>';
    echo '👤 Name: <strong>Foster Ackom</strong><br>';
    echo '🌍 Network: <strong>MTN</strong><br>';
    echo '📝 Wait patiently for your order to be delivered to you.<br>';
    echo '<em style="color:#555;">(Twi: Tua sika no kɔ 0201258303 so. Fa din no: Foster Ackom. Twɛn wo order no bɔkɔɔ.)</em><br>';
    echo '<img src="' . esc_url( plugin_dir_url(__FILE__) . 'assets/momo-qr.png' ) . '" alt="MoMo QR" style="max-width:120px; margin-top:10px;">';
    echo '</div>';
}

// Display on My Orders
add_action('woocommerce_my_account_my_orders_column_order-total', function($order) {
    if (in_array($order->get_status(), ['pending', 'on-hold'])) {
        anju_render_momo_payment_box();
    }
}, 20, 2);

// Display on Thank You
add_action('woocommerce_thankyou', function($order_id) {
    $order = wc_get_order($order_id);
    if (in_array($order->get_status(), ['pending', 'on-hold'])) {
        anju_render_momo_payment_box();
    }
}, 20);

// Display in Email
add_action('woocommerce_email_after_order_table', function($order, $sent_to_admin, $plain_text, $email) {
    if (!$sent_to_admin && in_array($order->get_status(), ['pending', 'on-hold'])) {
        anju_render_momo_payment_box();
    }
}, 10, 4);

// Show payment confirmation form
add_action('woocommerce_thankyou', function($order_id) {
    $order = wc_get_order($order_id);
    if (in_array($order->get_status(), ['pending', 'on-hold'])) {
        ?>
        <div style="margin-top:25px;">
            <h3>Confirm Your MoMo Payment</h3>
            <form method="post">
                <input type="hidden" name="anju_confirm_order_id" value="<?php echo esc_attr($order_id); ?>">
                <label>Your Name:</label><br>
                <input type="text" name="anju_payer_name" required><br><br>
                <label>MoMo Number Used:</label><br>
                <input type="text" name="anju_momo_number" required><br><br>
                <input type="submit" name="anju_confirm_payment" value="Confirm Payment">
            </form>
        </div>
        <?php
    }
});

// Save confirmation and send email
add_action('init', function() {
    if (isset($_POST['anju_confirm_payment'])) {
        global $wpdb;
        $table = $wpdb->prefix . "anju_momo_confirmations";

        $order_id = sanitize_text_field($_POST['anju_confirm_order_id']);
        $name = sanitize_text_field($_POST['anju_payer_name']);
        $momo = sanitize_text_field($_POST['anju_momo_number']);

        // Save to DB
        $wpdb->insert($table, [
            'order_id' => $order_id,
            'name' => $name,
            'momo_number' => $momo,
            'date_submitted' => current_time('mysql')
        ]);

        // Email admin
        $to = get_option('admin_email');
        $subject = "MoMo Payment Confirmation - Order #$order_id";
        $message = "Payment confirmed for Order #$order_id

Name: $name
MoMo Number: $momo
Order: " . get_edit_post_link($order_id);
        wp_mail($to, $subject, $message);

        // Update order status
        $order = wc_get_order($order_id);
        $order->update_status('processing', 'Payment confirmed manually by customer.');
    }
});

// Create DB table on plugin activation
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table = $wpdb->prefix . "anju_momo_confirmations";
    $charset = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table (
        id INT NOT NULL AUTO_INCREMENT,
        order_id INT,
        name VARCHAR(100),
        momo_number VARCHAR(20),
        date_submitted DATETIME,
        PRIMARY KEY (id)
    ) $charset;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
});

// Admin dashboard menu
add_action('admin_menu', function() {
    add_menu_page('MoMo Confirmations', 'MoMo Confirmations', 'manage_woocommerce', 'anju-momo-confirmations', 'anju_render_admin_page', 'dashicons-feedback');
});

// Show admin list
function anju_render_admin_page() {
    global $wpdb;
    $table = $wpdb->prefix . "anju_momo_confirmations";
    $results = $wpdb->get_results("SELECT * FROM $table ORDER BY date_submitted DESC");

    echo '<div class="wrap"><h1>MoMo Payment Confirmations</h1>';
    echo '<table class="widefat"><thead><tr><th>Date</th><th>Order #</th><th>Name</th><th>MoMo Number</th></tr></thead><tbody>';
    foreach ($results as $row) {
        echo '<tr>';
        echo '<td>' . esc_html($row->date_submitted) . '</td>';
        echo '<td><a href="' . esc_url(admin_url("post.php?post={$row->order_id}&action=edit")) . '">#' . esc_html($row->order_id) . '</a></td>';
        echo '<td>' . esc_html($row->name) . '</td>';
        echo '<td>' . esc_html($row->momo_number) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}
