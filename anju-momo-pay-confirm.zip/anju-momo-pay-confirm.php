<?php
/**
 * Plugin Name: Anju MoMo Pay & Confirm
 * Description: Adds Mobile Money instructions, Twi support, QR code, and payment confirmation to WooCommerce.
 * Version: 1.0
 * Author: Anju Data Hub
 */

defined( 'ABSPATH' ) || exit;

// Show payment box (used everywhere)
function anju_render_momo_payment_box() {
    echo '<div style="background:#f0f8ff; border:1px solid #ccc; padding:12px; margin-top:15px; font-size:14px;">';
    echo '<strong>Mobile Money Payment Details</strong><br>';
    echo '📱 <strong>0201258303</strong><br>';
    echo '👤 Name: <strong>Foster Ackom</strong><br>';
    echo '🌍 Network: <strong>MTN</strong><br>';
    echo '📝 Wait patiently for your order to be delivered to you.<br>';
    echo '<em style="color:#555;">(Twi: Tua sika no kɔ 0201258303 so. Fa din no: Foster Ackom. Twɛn wo order no bɔkɔɔ.)</em><br>';
    echo '<img src="' . esc_url( plugin_dir_url(__FILE__) . 'assets/momo-qr.png' ) . '" alt="MoMo QR" style="max-width:120px; margin-top:10px;">';
    echo '</div>';
}

// Add to My Orders
add_action('woocommerce_my_account_my_orders_column_order-total', function($order) {
    if (in_array($order->get_status(), ['pending', 'on-hold'])) {
        anju_render_momo_payment_box();
    }
}, 20, 2);

// Add to Thank You
add_action('woocommerce_thankyou', function($order_id) {
    $order = wc_get_order($order_id);
    if (in_array($order->get_status(), ['pending', 'on-hold'])) {
        anju_render_momo_payment_box();
    }
}, 20);

// Add to Email
add_action('woocommerce_email_after_order_table', function($order, $sent_to_admin, $plain_text, $email) {
    if (!$sent_to_admin && in_array($order->get_status(), ['pending', 'on-hold'])) {
        anju_render_momo_payment_box();
    }
}, 10, 4);

// Confirmation form
add_action('woocommerce_thankyou', function($order_id) {
    $order = wc_get_order($order_id);
    if (in_array($order->get_status(), ['pending', 'on-hold'])) {
        ?>
        <div style="margin-top:25px;">
            <h3>Confirm Your MoMo Payment</h3>
            <form method="post">
                <input type="hidden" name="anju_confirm_order_id" value="<?php echo esc_attr($order_id); ?>">
                <label>Your Name:</label><br>
                <input type="text" name="anju_payer_name" required><br><br>
                <label>MoMo Number Used:</label><br>
                <input type="text" name="anju_momo_number" required><br><br>
                <input type="submit" name="anju_confirm_payment" value="Confirm Payment">
            </form>
        </div>
        <?php
    }
});

// Process confirmation
add_action('init', function() {
    if (isset($_POST['anju_confirm_payment'])) {
        $order_id = sanitize_text_field($_POST['anju_confirm_order_id']);
        $name = sanitize_text_field($_POST['anju_payer_name']);
        $momo = sanitize_text_field($_POST['anju_momo_number']);

        $to = get_option('admin_email');
        $subject = "MoMo Payment Confirmation - Order #$order_id";
        $message = "Payment confirmed for Order #$order_id

Name: $name
MoMo Number: $momo
Order: " . get_edit_post_link($order_id);

        wp_mail($to, $subject, $message);

        $order = wc_get_order($order_id);
        $order->update_status('processing', 'Payment confirmed manually by customer.');
    }
});
